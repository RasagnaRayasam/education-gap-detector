from ocr_reader import extract_text_from_pdf, detect_semesters

# Path to your test PDF
pdf_path = "uploads/3rd sem memo.pdf"

# Extract text using Vision OCR
text = extract_text_from_pdf(pdf_path)

# Detect semesters in the extracted text
semesters = detect_semesters(text)

# Print the output
print("Detected Semesters:", semesters)

