from flask import Flask, request, render_template
import os
from ocr_reader import extract_text_from_pdf, detect_semesters

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files.get("cert")

        if not file or not file.filename.lower().endswith('.pdf'):
            return "❌ Please upload only ONE valid PDF file.", 400

        # Save uploaded file
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(save_path)

        # OCR extract text and detect semesters
        extracted_text = extract_text_from_pdf(save_path)
        found = detect_semesters(extracted_text)

        # Determine expected semesters based on entry type
        entry_type = request.form.get("entry_type", "regular").lower()
        expected = list(range(3, 9)) if entry_type == "lateral" else list(range(1, 9))
        missing = [s for s in expected if s not in found]

        return render_template("result.html",
                               filename=file.filename,
                               entry_type=entry_type,
                               found=found,
                               expected=expected,
                               missing=missing)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
