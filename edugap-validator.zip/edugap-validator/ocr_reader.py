import io
from pdf2image import convert_from_path
import tempfile
from google.cloud import vision
import os

# Initialize Vision API client
client = vision.ImageAnnotatorClient()

def extract_text_from_pdf(pdf_path):
    """
    Extracts text from scanned PDF using Google Vision OCR.
    Converts PDF pages to images, sends them to Vision API, and returns full text.
    """
    full_text = ""

    try:
        with tempfile.TemporaryDirectory() as path:
            images = convert_from_path(pdf_path, dpi=300, output_folder=path)

            for img in images:
                image_bytes = io.BytesIO()
                img.save(image_bytes, format='JPEG')
                img.close()  # ✅ Prevents WinError 32
                image_bytes.seek(0)

                image = vision.Image(content=image_bytes.read())
                response = client.text_detection(image=image)

                if response.error.message:
                    raise Exception(f'Vision API Error: {response.error.message}')

                text = response.full_text_annotation.text
                full_text += text + "\n"

    except Exception as e:
        print(f"Error processing {pdf_path}: {e}")

    print("=== OCR TEXT START ===")
    print(full_text)
    print("=== OCR TEXT END ===")
    return full_text


def detect_semesters(text):
    """
    Detects semester mentions using exact match phrases:
    Roman, ordinal, cardinal, and full word formats (like III SEM, SEMESTER 4TH, etc.)
    """
    text = text.upper().replace("\n", " ").replace("-", "-")
    text = " ".join(text.split())

    semesters = set()

    formats = {
        1: ["I", "1", "1ST", "FIRST"],
        2: ["II", "2", "2ND", "SECOND"],
        3: ["III", "3", "3RD", "THIRD"],
        4: ["IV", "4", "4TH", "FOURTH"],
        5: ["V", "5", "5TH", "FIFTH"],
        6: ["VI", "6", "6TH", "SIXTH"],
        7: ["VII", "7", "7TH", "SEVENTH"],
        8: ["VIII", "8", "8TH", "EIGHTH"]
    }

    prefixes = ["", "SEM ", "SEM-", "SEMESTER ", "SEMESTER-", "", "-SEM", "-SEMESTER"]
    suffixes = ["", " SEM", " SEMESTER", "-SEM", "-SEMESTER", ""]

    for number, tokens in formats.items():
        for token in tokens:
            for prefix in prefixes:
                for suffix in suffixes:
                    phrase = f"{prefix}{token}{suffix}"
                    if phrase in text:
                        semesters.add(number)

    return sorted(list(semesters))









